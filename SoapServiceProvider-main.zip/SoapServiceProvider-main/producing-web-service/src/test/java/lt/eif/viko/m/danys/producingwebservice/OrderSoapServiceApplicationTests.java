package lt.eif.viko.m.danys.producingwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderSoapServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
