package lt.eif.viko.m.danys.producingwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderSoapServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderSoapServiceApplication.class, args);
	}

}
